﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UIShell.OSGi;

namespace OSGi.NET.HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            using (BundleRuntime bundleRuntime = new BundleRuntime())
            {
                bundleRuntime.Start();

                //TODO

                Console.WriteLine("Press enter to exit...");
                Console.ReadLine();
            }
        }
    }
}
